/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

import io.dropwizard.Application;
import io.dropwizard.Configuration;
import io.dropwizard.setup.Environment;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.assets.AssetsBundle;

/**
 *
 * @author 31832091
 */
public class Servidor extends Application<Configuration> {

    public static void main(String[] args) throws Exception {
        new Servidor().run(new String[]{"server"});
    }

    @Override
    public void initialize(final Bootstrap<Configuration> bootstrap) {
        bootstrap.addBundle(new AssetsBundle("/html", "/", "index.html"));
    }
    

    @Override
    public void run(Configuration t, Environment e) throws Exception {
        CarroDAO dao = new CarroDAO();
        e.jersey().register(new CarroWeb(dao));
      
        
        ContaBancariaDAO da = new ContaBancariaDAO();
        e.jersey().register(new ContaWeb(da));
        e.jersey().setUrlPattern("/api/*");
    }
}
