/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Projeto;
/**
 *
 * @author 31832091
 */
public class ContaBancaria {
   
    private int id;
    private String nomeTitular;
    private int saldo;
    private int agencia;
    
    public ContaBancaria() {}
    
    public ContaBancaria(int id, String n, int s,int a) {
        this.id = id;
       this.nomeTitular=n;
       this.saldo=s;
       this.agencia=a;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomeTitular() {
        return nomeTitular;
    }

    public void setNomeTitular(String nomeTitular) {
        this.nomeTitular = nomeTitular;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public int getAgencia() {
        return agencia;
    }

    public void setAgencia(int agencia) {
        this.agencia = agencia;
    }
    

    @Override
    public String toString() {
        return "Conta Bancaria: " 
                + this.id + " ; " 
                + this.nomeTitular + " ; " 
                + this.saldo + " ;" 
                + this.agencia + ";";
    }
}


