/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 *  @author 31832091
 */
public class CarroDAO {
    private PreparedStatement stmC;
    private PreparedStatement stmR;
    private PreparedStatement stmU;
    private PreparedStatement stmD;
    
    private Connection conn;
   
    
    public CarroDAO() {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            this.conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Projeto","app","app");
            
            this.stmC = this.conn.prepareStatement("INSERT INTO carro(modelo,marca,ano,categoria) VALUES(?,?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            this.stmR = this.conn.prepareStatement("SELECT * FROM carro");
            this.stmU = this.conn.prepareStatement("UPDATE carro SET modelo=?, marca=?, ano=?, categoria=? WHERE id_carro=?");
            this.stmD = this.conn.prepareStatement("DELETE FROM carro WHERE id_carro=?");
        }catch(ClassNotFoundException e) {
            
            System.out.println("Erro CarroDao");
        }
        catch(SQLException e){
            System.out.println("Trativa");
        }
    }
    
    public void close(){
        try{
            this.conn.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public Carro create(Carro novoCarro) {
        try {
            this.stmC.setString(1, novoCarro.getModelo());
            this.stmC.setString(2, novoCarro.getMarca());
            this.stmC.setInt(3, novoCarro.getAno());
            this.stmC.setString(4, novoCarro.getCategoria());
            this.stmC.executeUpdate();
            
            ResultSet rs = this.stmC.getGeneratedKeys();
            rs.next();
            int id = rs.getInt(1);
            novoCarro.setId(id);
            
          
            return novoCarro;
        }catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public List<Carro> read() {
        try {
            ResultSet rs = this.stmR.executeQuery();
            
            List<Carro> carros = new ArrayList<>();
            
            while(rs.next()) {
                Carro c = new Carro();
                c.setId(rs.getInt("id_carro"));
                c.setModelo(rs.getString("modelo"));
                c.setMarca(rs.getString("marca"));
                c.setAno(rs.getInt("ano"));
                c.setCategoria(rs.getString("categoria"));
                
                carros.add(c);
             
            }
         
            return carros;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean update(Carro carro){
        try{
            stmU.setString(1, carro.getModelo());
            stmU.setString(2, carro.getMarca());
            stmU.setInt(3, carro.getAno());
            stmU.setString(4, carro.getCategoria());
            stmU.setInt(5, carro.getId());
             return this.stmU.executeUpdate()>0;
        
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean delete(int id){
        try{
            stmD.setLong(1, id);
            return this.stmD.executeUpdate()>0;
     
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
}
