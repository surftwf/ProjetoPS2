/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 * @author 31832091
 * 
 */
package Projeto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * 
 */
public class ContaBancariaDAO {
    private PreparedStatement stmC;
    private PreparedStatement stmR;
    private PreparedStatement stmU;
    private PreparedStatement stmD;
    
    private Connection conn;
   
    
    public ContaBancariaDAO() {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            this.conn = DriverManager.getConnection("jdbc:derby://localhost:1527/Projeto","app","app");
            
            this.stmC = this.conn.prepareStatement("INSERT INTO conta_bancaria(nome_titular,saldo,agencia) VALUES(?,?,?)",
                    Statement.RETURN_GENERATED_KEYS);
            this.stmR = this.conn.prepareStatement("SELECT * FROM conta_bancaria");
            this.stmU = this.conn.prepareStatement("UPDATE conta_bancaria SET nome_titular=?, saldo=?, agencia=? WHERE id_conta=?");
            this.stmD = this.conn.prepareStatement("DELETE FROM conta_bancaria WHERE id_conta=?");
        }catch(Exception e) {
            System.out.println("Erro ContaDao");
        }
    }
    
    public void close(){
        try{
            this.conn.close();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
    
    public List<ContaBancaria> read() {
        try {
            ResultSet rs = this.stmR.executeQuery();
            
            List<ContaBancaria> contas = new ArrayList<>();
            
            while(rs.next()) {
                ContaBancaria cb = new ContaBancaria();
                cb.setId(rs.getInt("id_conta"));
                cb.setNomeTitular(rs.getString("nome_titular"));
                cb.setSaldo(rs.getInt("saldo"));
                cb.setAgencia(rs.getInt("agencia"));
              
                
                contas.add(cb);
            }
            
            return contas;
        } catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }
 
    public ContaBancaria create(ContaBancaria novaConta) {
        try {
            this.stmC.setString(1, novaConta.getNomeTitular());
            this.stmC.setInt(2, novaConta.getSaldo());
            this.stmC.setInt(3, novaConta.getAgencia());
           
            this.stmC.executeUpdate();
            
            ResultSet rs = this.stmC.getGeneratedKeys();
            rs.next();
            int id = rs.getInt(1);
            novaConta.setId(id);
            
            return novaConta;
        }catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }
       public boolean  update(ContaBancaria novaConta){
        try{
            stmU.setString(1, novaConta.getNomeTitular());
            stmU.setInt(2, novaConta.getSaldo());
            stmU.setInt(3, novaConta.getAgencia());
            stmU.setInt(4, novaConta.getId());
            
            return this.stmU.executeUpdate()>0;
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean delete(int id){
        try{
            stmD.setInt(1, id);
             return this.stmD.executeUpdate()>0;
           
        }catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
    
}