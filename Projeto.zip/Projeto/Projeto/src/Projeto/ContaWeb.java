/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Projeto;

/**
 *
 * @author 31832091
 */
import io.dropwizard.jersey.params.IntParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

/**
 *
 * @author 31832091
 */
@Path("/contas")
@Produces(MediaType.APPLICATION_JSON)
public class ContaWeb {

    private ContaBancariaDAO dao;

    public ContaWeb(ContaBancariaDAO dao) {
        this.dao = dao;
    }

    @GET
    public List<ContaBancaria> get() {
        return dao.read();
    }

    @POST
    public ContaBancaria create(ContaBancaria conta) {
        return dao.create(conta);
    }

    @PUT
    @Path("{id}")
    public Response update(@PathParam("id") IntParam id, ContaBancaria conta) {
        conta.setId(id.get());
        if (dao.update(conta)) {
            return Response.ok().build();
        }
        throw new WebApplicationException(Response.Status.NOT_FOUND);
    }

    @DELETE
    @Path("{id}")
    public Response delete(@PathParam("id")  IntParam id, ContaBancaria conta){
    if (dao.delete(id.get())) {
            return Response.ok().build();
        }
        throw new WebApplicationException(Response.Status.NOT_FOUND);
    }
}
